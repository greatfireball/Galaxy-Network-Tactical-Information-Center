<?PHP
    $error_code_message[1] = 'Konnte keine Verbindung zur Datenbank aufbauen.';
    $error_code_message[2] = 'Konnte Datenbank nicht ausw�hlen.';
    $error_code_message[3] = 'Sie sind momentan nicht eingelogt.';
    $error_code_message[4] = 'Abrufen von Informationen aus der Datenbank fehlgeschlagen.';
    $error_code_message[5] = 'Sie sind nicht berechtigt diese Aktion auszuf�hren.';
    $error_code_message[6] = 'Das Formular wurde nur unvollst�ndig ausgef�llt.';
    $error_code_message[7] = 'Speichern von Daten in der Datenbank fehlgeschlagen.';
    $error_code_message[8] = 'Angeforderter Datensatz nicht gefunden.';
    $error_code_message[9] = 'Datensatz bereits vorhanden.';
    $error_code_message[10] = 'Der Account ist gesperrt. Wenden sie sich bitte an einen Techniker.';
    $error_code_message[11] = 'Diese Funktion ist im Moment deaktiviert. Wahrscheinlich wird sie gerade umgeschrieben.';
    $error_code_message[12] = 'F�r die Ausf�hrung ben�tige Daten wurden nicht gefunden.';
    $error_code_message[13] = 'Nachtwache ist bereits vergeben.';
    echo '<FONT COLOR=#FF0000><B>Fehler '.$error_code.': '.$error_code_message[$error_code].'</B></FONT>';
?>
