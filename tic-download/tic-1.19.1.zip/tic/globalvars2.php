<?php
    // Global Vars 2 f�r Funktions

    // Schiffe
    $Schiffe[0] = 'j';      // J�er
    $Schiffe[1] = 'b';      // Bomber
    $Schiffe[2] = 'f';      // Fregatte
    $Schiffe[3] = 'z';      // Zerst�er
    $Schiffe[4] = 'kr';     // Kreuzer
    $Schiffe[5] = 'sa';     // Schlachtschiff
    $Schiffe[6] = 't';      // Tr�erschiff
    $Schiffe[7] = 'ko';     // Kommandoschiff
    $Schiffe[8] = 'ka';     // Kaperschiff
    $Schiffe[9] = 'su';     // Schutzschiff

    $SF[0] = 'Jaeger';
    $SF[1] = 'Bomber';
    $SF[2] = 'Fregatte';
    $SF[3] = 'Zerstoerer';
    $SF[4] = 'Kreuzer';
    $SF[5] = 'Schlachtschiff';
    $SF[6] = 'Traegerschiff';
    $SF[7] = 'Kommandoschiff';
    $SF[8] = 'Kaperschiff';
    $SF[9] = 'Schutzschiff';

    // Defensiveinheiten
    $Defensiv[0] = 'lo';    // Leichtes Orbitalgeschtz
    $Defensiv[1] = 'lr';    // Leichtes Raumgeschtz
    $Defensiv[2] = 'mr';    // Mittleres Raumgeschtz
    $Defensiv[3] = 'sr';    // Schweres Raumgeschtz
    $Defensiv[4] = 'a';     // Abfangj�er
    $Defensiv[5] = 'r';     // Raumbasis

    $DF[0] = 'Leichtes Gesch�tz - Rubium';
    $DF[1] = 'Mittleres Gesch�tz - Pulsar';
    $DF[2] = 'Mittleres Gesch�tz - Coon';
    $DF[3] = 'Schweres Gesch�tz - Centurio';
    $DF[4] = 'Abfangj�ger - Horus';
//
    $EF[0] = 'Metall-Extraktoren';
    $EF[1] = 'Kristall-Extraktoren';
    $EF[2] = 'Punkte';
    $EF[3] = 'Schiffe';
    $EF[4] = 'Deff-Einheiten';

    $PIC[0] = 'scanwarn.gif';
    $PIC[1] = 'scanok.gif';
    $PIC[2] = 'scanold.gif';

    $ATTOVERALL = 3;


?>

