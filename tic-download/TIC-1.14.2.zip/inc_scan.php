<CENTER>
	<TABLE>
		<TR>
			<TD BGCOLOR=#333333><FONT COLOR=#FFFFFF><B>Scan hinzuf�gen</B></FONT></TD>
		</TR>
		<TR>
			<TD>
				<P CLASS="hell">
					<FORM ACTION="./main.php" METHOD="POST">
						<INPUT TYPE="hidden" NAME="modul" VALUE="scan">
						<INPUT TYPE="hidden" NAME="action" VALUE="addscan">
						<TEXTAREA COLS=50 ROWS=25 NAME="txtScan"></TEXTAREA><BR>
						<INPUT TYPE="submit" VALUE="Speichern">
					</FORM>
				</P>
			</TD>
		</TR>
	</TABLE>
</CENTER>