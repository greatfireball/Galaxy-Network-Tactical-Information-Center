<?
session_destroy();
echo 'Ausgelogt, ich w&uuml;nsche ihnen einen sch&ouml;en Tag Sie werden in 5 Sekunden zum Login weiter geleitet!';
echo '<meta http-equiv="refresh" content="5; URL=./index.php">';
?>
