<table align="center">
  <tr>
    <td class="datatablehead">Statistic</td>
  </tr>
  <tr>
    <td class="fieldnormallight" width="137"><a href="./main.php?modul=statistik">TIC-Info</a></td>
  </tr>
  <tr>
    <td class="fieldnormallight" width="137"><a href="./main.php?modul=show_login&amp;sort=ASC">Anmeldezeiten</a></td>
  </tr>
  <tr>
    <td class="fieldnormallight" width="137"><a href="./main.php?modul=rankings">Rankings</a></td>
  </tr>
</table>