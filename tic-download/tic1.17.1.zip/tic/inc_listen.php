<table align="center">
  <tr>
    <td bgcolor="#6490BB" class="datatablehead">Listen</td>
  </tr>
  <tr>
    <td bgcolor="#6490BB" class="fieldnormallight" width="137"><a href="./main.php?modul=allifleets">Flotten</a></td>
  </tr>
  <tr>
    <td bgcolor="#6490BB" class="fieldnormallight" width="137"><a href="./main.php?modul=allianz">Alli-&Uuml;bersicht</a></td>
  </tr>
  <tr>
    <td bgcolor="#6490BB" class="fieldnormallight" width="137"><a href="./main.php?modul=scanner">Scanner</a></td>
  </tr>
  <tr>
    <td bgcolor="#6490BB" class="fieldnormallight" width="137"><a href="./main.php?modul=kontakt">Kontakt</a></td>
  </tr>
  <tr>
    <td bgcolor="#6490BB" class="fieldnormallight" width="137"><a href="./main.php?modul=telelist">Telefonliste</a></td>
  </tr>
  <tr>
    <td bgcolor="#6490BB" class="fieldnormallight" width="137"><a href="./main.php?modul=zielsuche">Zielsuche</a></td>
  </tr>
  <tr>
    <td bgcolor="#6490BB" class="fieldnormallight" width="137"><a href="./main.php?modul=icq">ICQ Status</a></td>
  </tr>
</table>
