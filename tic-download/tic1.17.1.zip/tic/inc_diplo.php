<TABLE WIDTH=100% CELLSPACING="6" border="0" cellpadding="1">
  <TR bgcolor="#dddddd">
    <TD VALIGN="top">
      <TABLE CELLSPACING=0 width="98%" bgcolor="#dddddd">
    <TD ALIGN="right" VALIGN="top">
      <TABLE CELLSPACING=0 bgcolor="#dddddd">
        <TR>
          <TD><font size="-1">B�ndnisse:</font></TD>
          <TD><font size="-1">
            <?=$AllianzInfo[$Benutzer['allianz']]['info_bnds']?>
            </font></TD>
        </TR>
        <TR>
          <TD><font size="-1">Offizielle NAP's:</font></TD>
          <TD><font size="-1">
            <?=$AllianzInfo[$Benutzer['allianz']]['info_naps']?>
            </font></TD>
        </TR>
        <TR>
          <TD><font size="-1">Inoffizielle NAP's:</font></TD>
          <TD><font size="-1">
            <?=$AllianzInfo[$Benutzer['allianz']]['info_inoffizielle_naps']?>
            </font></TD>
        </TR>
        <TR>
          <TD><font size="-1">Kriege:</font></TD>
          <TD><font size="-1">
            <?=$AllianzInfo[$Benutzer['allianz']]['info_kriege']?>
            </font></TD>
        </TR>
      </TABLE>
    </TD>
  </TR>
</TABLE>
<BR>
